
const Discord = require('discord.js');
const bot = new Discord.Client();
const token = 'NDk5MjY2MjcwNjc2NjQ3OTU2.Dp50Ow.XCnjsKLHuXLuvvHKWZQr4slI2ro';

var badWords = ["fuck","ass","bastard","bitch","cock","dick","cunt","pussy","shit","damn","piss","hell ","gay","lesbian","racist"];
bot.on("message", function(message){
       var arrayLength = badWords.length;
       for (var i = 0; i < arrayLength; i++) {
            str = message.content;
            str = str.replace(/\s/g, ''); 
        if(str.toLowerCase().includes(badWords[i])){
            message.reply("Please do not say that bad word. It is against our <#422915211339759616>. Keep it PG");
            message.delete();
       } else{
	   }	
   }
});

bot.login(token);